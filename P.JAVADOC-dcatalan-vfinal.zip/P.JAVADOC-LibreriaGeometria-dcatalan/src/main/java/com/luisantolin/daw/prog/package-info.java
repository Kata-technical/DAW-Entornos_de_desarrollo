/**
 * Es el paquete principal.
 * Contiene la clase App con el método main para ejecutar el programa.
 */
package com.luisantolin.daw.prog;